package com.example.movie;

public class MovieList {
    MovieListResult boxOfficeResult;
}
